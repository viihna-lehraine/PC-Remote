// File: backend/src/ws/gestures.ts

// import { WebSocket } from 'ws';

// export function handleGestureSocket(ws: WebSocket, message: string) {
// 	console.log('Received gesture data:', message);
// }
